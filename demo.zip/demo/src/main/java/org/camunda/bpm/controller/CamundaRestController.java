package org.camunda.bpm.controller;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CamundaRestController {
	
	  @Autowired
	  private ProcessEngine camunda;
	  
	  
	  @PostMapping("/scriptexecutor/")
	  public void unlockUser(@RequestParam("filepath") String path) {
	     executejob(path);
	  }

	private ProcessInstance executejob(String path) {
		return camunda.getRuntimeService().startProcessInstanceByKey("ScriptExecutionProcess",Variables.putValue("filepath", path));
		
	}
	  
}
