package org.camunda.bpm.delegate;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.service.ScriptExecutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ScriptExecutorTaskDelegate implements JavaDelegate {

	@Autowired
	RuntimeService runtimeService;
	
	@Autowired
	ScriptExecutionService scriptExecutionService;
	
	public void execute(DelegateExecution ctx) throws Exception {
		String filepath=(String)ctx.getVariable("filepath");
		System.out.println("Receved a task for executing file :"+filepath);
		scriptExecutionService.executeScript(filepath);
	}

}
