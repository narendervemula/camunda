package org.camunda.bpm.service;

public interface ScriptExecutionService {
	
	public void executeScript(String filepatch);
	

}
