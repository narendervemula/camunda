package org.camunda.bpm.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.camunda.bpm.service.ScriptExecutionService;
import org.springframework.stereotype.Service;

@Service("scriptExecutionService")
public class ScriptExecutionServiceImpl implements ScriptExecutionService{

	public void executeScript(String filepatch) {
		
		try {
			Process p = Runtime.getRuntime().exec(filepatch);
			p.waitFor();
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = "";
            while ((line = input.readLine()) != null) {
                System.out.println(line);
            }
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}

}
